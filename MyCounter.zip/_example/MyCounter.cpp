#include "“MyCounter.h"
MyCounter::MyCounter(const int btnPin,
                     const int ledPin,
                     const int timeSecond = 10,
                     const bool btnPinActive = LOW,
                     const bool ledPinActive = LOW);
                     
