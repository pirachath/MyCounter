#ifndef MYCOUNTER_H
#define MYCOUNTER_H

#include <Arduino.h>

class MyCounter {
public:

  Mycounter(const int btnPin,
            const int ledPin,
            const int timeSecond = 10,
            const bool btnPinActive = LOW,
            const bool ledPinActive = LOW);

~MyCounter();
// set time seconde
 void setTimeSecond(const int timeSecond);
 // loop (event handler)
 void loop();

 private:
    MyCounter(const bool ledPinActive = LOW);
              const bool btnPinActive = LOW,
              const int timeSecond = 10,
              const int ledPin,
              const int btnPin,

  :
  
};

#endif
